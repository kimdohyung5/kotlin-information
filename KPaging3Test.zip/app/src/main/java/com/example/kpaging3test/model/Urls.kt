package com.example.kpaging3test.model

import kotlinx.serialization.Serializable

@Serializable
data class Urls(
    val regular: String
)
