package com.example.kpaging3test.model

import kotlinx.serialization.Serializable

@Serializable
data class UserLinks(
    val html: String
)